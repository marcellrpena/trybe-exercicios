from abc import ABC, abstractmethod


# Garantia de codigo
class PersonagemInterface(ABC):
    @abstractmethod
    def falar():
        ...
