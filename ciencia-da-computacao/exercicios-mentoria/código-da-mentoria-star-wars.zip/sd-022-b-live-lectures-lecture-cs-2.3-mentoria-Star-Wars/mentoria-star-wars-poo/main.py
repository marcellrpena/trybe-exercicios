from personagem import Personagem
from jedi_sit import Jedi, Sits

personagem1 = Personagem(nome='Anakin', especie='Humano', hp=255)
personagem2 = Jedi(nome='Nerus', especie='Humano', hp=300)
personagem3 = Sits(nome='Drakar', especie='Humano', hp=300)

# print(vars(p1))
# {'nome': 'Anakin', 'especie': 'Humano', 'hp': 255}

print("----------------")
print("BATALHA")
print(f"{personagem3.nome}: {personagem3.falar()}")
print(f"{personagem2.nome}: {personagem2.falar()}\n\n")

while personagem3.hp > 0:
    print(
        f"{personagem3.nome} (HP {personagem3.hp}) ataca {personagem2.nome} (HP {personagem2.hp})"
    )
    personagem3.ataque(personagem2)
    personagem2.falar()
    if personagem2.hp > 0:
        print(
            f"{personagem2.nome} (HP {personagem2.hp}) contra-ataca {personagem3.nome} (HP {personagem3.hp})"
        )
        personagem2.contra_ataca(personagem3)
        personagem3.falar()
    else:
        break
