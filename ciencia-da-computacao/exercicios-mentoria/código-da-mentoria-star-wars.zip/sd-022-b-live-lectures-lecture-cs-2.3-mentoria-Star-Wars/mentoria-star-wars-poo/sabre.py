class Sabre():
    def __init__(self, cor, forca):
        self.cor = cor
        self.forca = forca
