from personagem import Personagem
from sabre import Sabre
from random import choice


# Classe com heranca
# Malvadao
class Sits(Personagem):
    def __init__(self, nome, especie, hp):
        super().__init__(nome, especie, hp)
        # COMPOSICAO
        self.sabre = Sabre(cor='Vermelho', forca=90)

    def falar(self):
        # If com return nao precisa de else
        if self.hp <= 0:
            print(f"Acho que {self.nome} vai morrer.")

        return "Perdeu playboy!"

    def ataque(self, personagem):
        if not personagem.defender():
            personagem.set_hp(dano=self.sabre.forca)


# Classe com heranca
# Bosinho
class Jedi(Personagem):
    def __init__(self, nome, especie, hp):
        super().__init__(nome, especie, hp)
        # COMPOSICAO
        self.sabre = Sabre(cor='Azul', forca=40)

    def falar(self):
        # If com return nao precisa de else
        if self.hp <= 0:
            print(f"É cilada {self.nome}.")

        return "Eu posso fazer isso o dia todo!"

    def defender(self):
        return choice([False, True])

    def contra_ataca(self, personagem):
        personagem.set_hp(dano=self.sabre.forca)
