from interface import PersonagemInterface


class Personagem(PersonagemInterface):
    def __init__(self, nome, especie, hp):
        self.nome = nome
        self.especie = especie
        self.__hp = hp

    @property
    def hp(self):
        return self.__hp

    def set_hp(self, dano):
        self.__hp -= dano

    def falar(self):
        return "É uma armadilha."
